# PMGD Farol — PWA (GitHub Pages, offline)

App PWA instalable (offline) para buscar TK, simular NETID→TK global y listar/filtros.
- Guarda el último CSV cargado en **localStorage** (solo en tu dispositivo).
- Botón **Instalar** (Android/Chrome) vía *beforeinstallprompt*.
- **Exportar CSV** y **Restaurar CSV de fábrica**.
- Cabecera **CSP** para limitar orígenes (`default-src 'self'`).

## Publicar en GitHub Pages
1. Crea repo público (ej. `pmgd-farol`).
2. Sube **todo** el contenido a la raíz del repo (incluye `.nojekyll` si lo agregas).
3. Settings → Pages → Source: **Deploy from a branch**, Branch: **main**, **/(root)** → Save.
4. Espera ~1 min: `https://robrock7777.github.io/Farol/`

## Actualizar el QR
La imagen `assets/qr_placeholder.png` apunta a `https://robrock7777.github.io/Farol/`.
Reemplázala con tu URL real (puedes generar el PNG con cualquier generador de QR).

## CSV
Formato: `TK,Plataforma,ID_local,NETID,Lora_Channel,Strings`
- `Strings` admite lista separada por `;` o forma `[a,b,c]` (sin espacios).
- La app guarda el CSV en `localStorage` y lo usará por defecto aun sin conexión.


## Publicar con GitHub Actions (recomendado)
1. Crea un repositorio público llamado **Farol** en la cuenta **robrock7777**.
2. Sube **todos** los archivos de esta carpeta a la **raíz** del repo (incluye `.nojekyll` y `.github/workflows/pages.yml`).
3. Ve a **Settings → Pages** y en **Build and deployment / Source** selecciona **GitHub Actions**.
4. Haz un **commit/push** a `main`. El workflow publicará en: **https://robrock7777.github.io/Farol/**
5. En Android → abre la URL en Chrome → **⋮** → **Añadir a pantalla de inicio**.

